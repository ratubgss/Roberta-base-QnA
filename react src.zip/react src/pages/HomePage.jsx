const HomePage = () => {
  return (
    <div>
      <div className="header-text">
        <p>I'm Here To Help You</p>
        <h1>
          Hi, Im <span>Yourvoice Chat</span>
          <br /> From Indonesia
        </h1>
      </div>
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <div className="copyright">
        <p>©YourvoiceIdn - 2023</p>
      </div>
    </div>
  );
};
export default HomePage;
